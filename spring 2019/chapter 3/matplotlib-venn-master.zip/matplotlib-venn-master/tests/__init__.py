'''
Venn diagram plotting routines.

Tests. Meant to be used via py.test.

Copyright 2012, Konstantin Tretyakov.
http://kt.era.ee/

Licensed under MIT license.
'''
